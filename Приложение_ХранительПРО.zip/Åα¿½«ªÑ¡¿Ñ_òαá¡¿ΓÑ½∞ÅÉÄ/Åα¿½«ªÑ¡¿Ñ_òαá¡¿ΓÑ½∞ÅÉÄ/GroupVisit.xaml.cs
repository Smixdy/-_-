﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static Приложение_ХранительПРО.GroupVisit;


namespace Приложение_ХранительПРО
{
    /// <summary>
    /// Логика взаимодействия для GroupVisit.xaml
    /// </summary>
    public partial class GroupVisit : Window
    {
        private ObservableCollection<GroupVisitor> groupVisitors = new ObservableCollection<GroupVisitor>();

        public class GroupVisitor
        {
            public int ID_Авторизации { get; set; }
            public string Фамилия { get; set; }
            public string Имя { get; set; }
            public string Отчество { get; set; }
            public string Телефон { get; set; }
            public string Email { get; set; }
            public string Организация { get; set; }
            public string Примечание { get; set; }
            public DateTime Дата_рождения { get; set; }
            public int Серия_паспорта { get; set; }
            public int Номер_паспорта { get; set; }
            public byte[] Фотография_посетителя { get; set; }
            public byte[] Скан_паспорта { get; set; }
            public GroupVisitor(byte[] photoData, byte[] scanData)
            {
                Фотография_посетителя = photoData;
                Скан_паспорта = scanData;
            }
        }

        private byte[] loadedPhotoData = null;
        private byte[] loadedScanData = null;
        private int authorizationId;

        public GroupVisit()
        {
            InitializeComponent();
            Loaded += OnLoaded;
        }

        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            // Заполняем ComboBox при загрузке окна
            using (var context = new ХранительПРОEntities())
            {
                Podrazdel.ItemsSource = context.Подразделение.ToList();
                Podrazdel.DisplayMemberPath = "Название_подразделения";
                Podrazdel.SelectedValuePath = "ID_Подразделения";

                sotrudnik.ItemsSource = context.Сотрудник.ToList();
                sotrudnik.DisplayMemberPath = "Фамилия";
                sotrudnik.SelectedValuePath = "ID_Сотруника";
            }
        }

        private void clear_Click(object sender, RoutedEventArgs e)
        {
            // Очистка формы
            Фамилия.Text = "";
            Имя.Text = "";
            Отчество.Text = "";
            Телефон.Text = "";
            Email.Text = "";
            Организация.Text = "";
            Примечание.Text = "";
            Дата_рождения.SelectedDate = null;
            Серия.Text = "";
            Номер.Text = "";
            date1.SelectedDate = null;
            date2.SelectedDate = null;

            loadedPhotoData = null;
            loadedImage.Source = null;
        }

        private byte[] LoadImage()
        {
            // Функция для загрузки изображения из файла
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image files (*.png;*.jpeg;*.jpg;*.pdf)|*.png;*.jpeg;*.jpg;*.pdf";
            if (openFileDialog.ShowDialog() == true)
            {
                return File.ReadAllBytes(openFileDialog.FileName);
            }
            return null;
        }

        private void foto_Click(object sender, RoutedEventArgs e)
        {
            loadedPhotoData = LoadImage();
            if (loadedPhotoData != null)
            {
                var bitmapImage = new BitmapImage();
                bitmapImage.BeginInit();
                bitmapImage.StreamSource = new MemoryStream(loadedPhotoData);
                bitmapImage.EndInit();

                // Устанавливаем BitmapImage как источник для элемента Image
                loadedImage.Source = bitmapImage;
            }
        }

        private void fail_Click(object sender, RoutedEventArgs e)
        {
            loadedScanData = LoadImage();
        }

        private void press_Click(object sender, RoutedEventArgs e)
        {
            if (groupVisitors.Count < 2)
            {
                MessageBox.Show("Для групповой заявки необходимо добавить как минимум 2 посетителя.");
                return;
            }

            using (var context = new ХранительПРОEntities())
            {
                // Проверка выбранных дат и значений комбобоксов
                if (date1.SelectedDate == null || date2.SelectedDate == null ||
                    Podrazdel.SelectedValue == null || sotrudnik.SelectedValue == null)
                {
                    MessageBox.Show("Пожалуйста, проверьте корректность данных.");
                    return;
                }

                // 1. Создаем заявку 
                var заявка = new Заявка
                {

                    Дата_подачи = DateTime.Now.Date,
                    Желаемый_срок_начала_пропуска = date1.SelectedDate.Value,
                    Желаемый_срок_окончания_пропуска = date2.SelectedDate.Value,
                    Групповая_запись = true,
                    Статус_заявки = 1,
                    Ответственное_подразделение = (int)Podrazdel.SelectedValue,
                    ID_Принимающего = (int)sotrudnik.SelectedValue
                };

                // 2. Сохраняем заявку, чтобы получить ID 
                context.Заявка.Add(заявка);
                context.SaveChanges();

                // 3. Добавляем посетителей и связываем их с заявкой
                foreach (var groupVisitor in groupVisitors)
                {
                    var visitor = new Посетитель
                    {
                        Фамилия = groupVisitor.Фамилия,
                        Имя = groupVisitor.Имя,
                        Отчество = groupVisitor.Отчество,
                        Телефон = groupVisitor.Телефон,
                        Почта = groupVisitor.Email,
                        Организация = groupVisitor.Организация,
                        Примечание = groupVisitor.Примечание,
                        Дата_рождения = groupVisitor.Дата_рождения,
                        Серия_паспорта = groupVisitor.Серия_паспорта,
                        Номер_паспорта = groupVisitor.Номер_паспорта,
                        Фотография_посетителя = groupVisitor.Фотография_посетителя,
                        Скан_паспорта = groupVisitor.Скан_паспорта,
                        ID_Авторизации = MainWindow.authorizationId,
                        ID_Заявки = заявка.ID_Заявки  // <-- Добавляем ID_Заявки
                    };

                    context.Посетитель.Add(visitor);
                    context.SaveChanges();
                    // 4. Создаем связь в таблице Посетитель_Заявка
                    var visitorApplication = new Посетитель_Заявка
                    {
                        ID_Заявки = заявка.ID_Заявки, // Используем ID сохраненной заявки
                        ID_Посетителя = visitor.ID_Посетителя // Используем ID сохраненного посетителя 
                    };
                    context.Посетитель_Заявка.Add(visitorApplication);
                }

                // 5. Сохраняем изменения в базе данных
                context.SaveChanges();

                MessageBox.Show("Групповая заявка успешно оформлена!");

            }
        }

        private bool ValidateForm()
        {
            // Проверка длины полей и наличия фото/скана 
            if (Серия.Text.Length > 4 || Номер.Text.Length > 6 ||
                Фамилия.Text.Length > 50 || Имя.Text.Length > 50 || Отчество.Text.Length > 50 ||
                Email.Text.Length > 50 || Организация.Text.Length > 50 || Примечание.Text.Length > 50 ||
                Телефон.Text.Length > 20 || loadedPhotoData == null || loadedScanData == null)
            {
                MessageBox.Show("Пожалуйста, проверьте корректность данных.");
                return false;
            }


            return true;
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            if (!ValidateForm()) return; // Проверка формы

            int серия, номер;
            if (!int.TryParse(Серия.Text, out серия) || !int.TryParse(Номер.Text, out номер))
            {
                MessageBox.Show("Пожалуйста, введите корректные серию и номер паспорта (только цифры).");
                return;
            }
            var visitor = new GroupVisitor(loadedPhotoData, loadedScanData)
            {
                ID_Авторизации = MainWindow.authorizationId,
                Фамилия = Фамилия.Text,
                Имя = Имя.Text,
                Отчество = Отчество.Text,
                Телефон = Телефон.Text,
                Email = Email.Text,
                Организация = Организация.Text,
                Примечание = Примечание.Text,
                // Проверка SelectedDate перед получением значения
                Дата_рождения = Дата_рождения.SelectedDate.HasValue ? Дата_рождения.SelectedDate.Value : DateTime.MinValue,
                Серия_паспорта = серия,
                Номер_паспорта = номер
            };

            // Добавляем посетителя в список
            groupVisitors.Add(visitor);

            // Обновляем DataGrid
            dataGrid.ItemsSource = null;
            dataGrid.ItemsSource = groupVisitors;

            // Очищаем форму
            clear_Click(sender, e);
        }
    }
}