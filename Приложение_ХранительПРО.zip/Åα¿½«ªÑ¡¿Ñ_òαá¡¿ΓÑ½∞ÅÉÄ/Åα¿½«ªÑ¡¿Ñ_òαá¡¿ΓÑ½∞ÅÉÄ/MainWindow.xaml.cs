﻿    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Security.Cryptography;
    using System.Text;
    using System.Threading.Tasks;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Data;
    using System.Windows.Documents;
    using System.Windows.Input;
    using System.Windows.Media;
    using System.Windows.Media.Imaging;
    using System.Windows.Navigation;
    using System.Windows.Shapes;

    namespace Приложение_ХранительПРО
    {
        /// <summary>
          /// Логика взаимодействия для MainWindow.xaml
          /// </summary>
        public partial class MainWindow : Window
        {
            public static int authorizationId;
            public MainWindow()
            {
                InitializeComponent();
            }

            private void Button_Click(object sender, RoutedEventArgs e)
            {
                using (var db = new ХранительПРОEntities())
                {
                    string login = Login.Text;
                    string password = Password.Text;

                    // Получение хеша пароля (MD5)
                    string hashedPassword = GetHashedPassword(password);

                    // Авторизация для посетителя
                    var visitor = db.Авторизация.FirstOrDefault(user => user.Логин == login && user.Шифрование == hashedPassword);
                    if (visitor != null)
                    {
                    Window easyUserWindow = new EasyUserWindow(authorizationId, visitor);
                    easyUserWindow.Show();
                    authorizationId = visitor.ID_Авторизации; // Сохранить ID_Авторизации
                        OpenEasyUserWindow();
                        MessageBox.Show("Вы авторизованы как посетитель");
                    }

                    // Авторизация для сотрудника
                    var employee = db.Сотрудник.FirstOrDefault(user => user.Фамилия == login && user.ID_Сотруника.ToString() == password);
                    if (employee != null)
                    {
                        OpenAdminWindow();
                        MessageBox.Show("Вы авторизованы как сотрудник");
                    }

                    if (visitor == null && employee == null)
                    {
                        MessageBox.Show("Неверно введен логин или пароль, либо же у вас нет доступа");
                    }
                }
            }

            /// <summary>
                /// Получает хеш пароля с помощью MD5 (не рекомендуется)
                /// </summary>
                /// <param name="password">Пароль пользователя</param>
                /// <returns>Хеш пароля</returns>
            private string GetHashedPassword(string password)
            {
                using (var md5 = MD5.Create())
                {
                    byte[] hashBytes = md5.ComputeHash(Encoding.UTF8.GetBytes(password));
                    string hashedPassword = BitConverter.ToString(hashBytes).Replace("-", "");
                    return hashedPassword;
                }
            }

            private void OpenEasyUserWindow()
            {
           
            }

            private void OpenAdminWindow()
            {
                Window EasyUserWindow = new AdminWindow();
                EasyUserWindow.Show();
            }

            private void Reg_Click(object sender, RoutedEventArgs e)
            {
                Window registration = new registration();
                registration.Show();
            }
        }
    }
