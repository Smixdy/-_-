﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Приложение_ХранительПРО
{
    /// <summary>
    /// Логика взаимодействия для Spisok.xaml
    /// </summary>
    public partial class Spisok : Window
    {
        private int authorizationId;
        public Spisok(int authorizationId)
        {
            InitializeComponent();
            this.authorizationId = authorizationId;
            Loaded += OnLoaded;
        }
        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            LoadApplications();
        }

        private void LoadApplications()
        {
            using (var context = new ХранительПРОEntities4())
            {
                // Найти ID_Посетителя по ID_Авторизации
                var visitorId = context.Посетитель.Where(p => p.ID_Авторизации == authorizationId).Select(p => p.ID_Посетителя).FirstOrDefault();

                // Найти заявки пользователя
                var applications = context.Заявка
                .Where(z => z.ID_Постетителя == visitorId)
                .Select(z => new
                {
                    z.ID_Заявки,
                    z.Дата_подачи,
                    z.Желаемый_срок_начала_пропуска,
                    z.Желаемый_срок_окончания_пропуска,
                    Статус = z.Статус.Название_статус, 
                    Сотрудник = z.Сотрудник.Фамилия + " " + z.Сотрудник.Имя + " " + z.Сотрудник.Отчество,
                    Подразделение = z.Подразделение.Название_подразделения
                })
                .ToList();

                applicationList.ItemsSource = applications;
            }
        }
    }
}