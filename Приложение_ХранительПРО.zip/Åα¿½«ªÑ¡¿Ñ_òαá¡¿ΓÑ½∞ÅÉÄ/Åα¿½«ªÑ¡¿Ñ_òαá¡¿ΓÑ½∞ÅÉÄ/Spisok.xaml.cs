﻿using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace Приложение_ХранительПРО
{
    public partial class Spisok : Window
    {
        private int authorizationId;
        private Авторизация authData;

        public Spisok(int authorizationId, Авторизация authData)
        {
            InitializeComponent();
            this.authorizationId = authorizationId;
            this.authData = authData;
            Loaded += OnLoaded;
        }

        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            LoadApplications();
        }

        private void LoadApplications()
        {
            using (var context = new ХранительПРОEntities())
            {
               

                // 2. Найти заявки пользователя (индивидуальные и групповые)
                var applications = context.Заявка
                    .Where(z =>
                        // Индивидуальные заявки: подзапрос проверяет наличие связи с посетителем
                        (!z.Групповая_запись && context.Посетитель.Any(p => p.ID_Посетителя == z.ID_Постетителя && p.ID_Авторизации == authorizationId)) ||
                        // Групповые заявки: подзапрос проверяет наличие связи с посетителем через Посетитель_Заявка
                        (z.Групповая_запись && context.Посетитель_Заявка.Any(pz => pz.ID_Заявки == z.ID_Заявки && context.Посетитель.Any(p => p.ID_Посетителя == pz.ID_Посетителя && p.ID_Авторизации == authorizationId))))
                    .Select(z => new
                    {
                        Тип = z.Групповая_запись ? "Групповая" : "Индивидуальная",
                        z.ID_Заявки,
                        z.Дата_подачи,
                        z.Желаемый_срок_начала_пропуска,
                        z.Желаемый_срок_окончания_пропуска,
                        Статус = z.Статус.Название_статус,
                        Подразделение = z.Подразделение.Название_подразделения,
                        Ответственный = z.Сотрудник.Фамилия + " " + z.Сотрудник.Имя + " " + z.Сотрудник.Отчество
                    })
                    .ToList();

                applicationList.ItemsSource = applications;
            }
        }
        }
    }
