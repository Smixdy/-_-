﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Приложение_ХранительПРО
{
    public partial class EasyUserWindow : Window
    {
        private int authorizationId;
        private Авторизация authData; // Добавляем поле для хранения данных авторизации

        public EasyUserWindow(int authorizationId, Авторизация authData) // Добавляем параметр authData
        {
            InitializeComponent();
            this.authorizationId = authorizationId;
            this.authData = authData; // Сохраняем данные авторизации
        }

        private void PersonalVisit_Click(object sender, RoutedEventArgs e)
        {
            Window personalVisitWindow = new PersonalVisit(MainWindow.authorizationId); // Получить authorizationId из MainWindow
            personalVisitWindow.Show();

        }
        private int GetAuthorizationId()
        {
            return authorizationId;
        }

        private void spisok_Click(object sender, RoutedEventArgs e)
        {
            using (var context = new ХранительПРОEntities())
            {
                var authData = context.Авторизация.Find(authorizationId);
            }

            Window spisokWindow = new Spisok(MainWindow.authorizationId, authData);
            spisokWindow.Show();
        }

        private void GroupVisit_Click(object sender, RoutedEventArgs e)
        {
            Window GroupVisit= new GroupVisit(); // Получить authorizationId из MainWindow
            GroupVisit.Show();
        }
    }
}
