﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Приложение_ХранительПРО
{
    public partial class EasyUserWindow : Window
    {
        private static int authorizationId;
        public EasyUserWindow()
        {
            InitializeComponent();
        }

        private void PersonalVisit_Click(object sender, RoutedEventArgs e)
        {
            Window personalVisitWindow = new PersonalVisit(MainWindow.authorizationId); // Получить authorizationId из MainWindow
            personalVisitWindow.Show();

        }
        private int GetAuthorizationId()
        {
            return authorizationId;
        }

        private void spisok_Click(object sender, RoutedEventArgs e)
        {
            Window Spisok = new Spisok(MainWindow.authorizationId);
            Spisok.Show();
        }
    }
}
