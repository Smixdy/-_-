﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Security.Cryptography;

namespace Приложение_ХранительПРО
{
    /// <summary>
    /// Логика взаимодействия для registration.xaml
    /// </summary>
    public partial class registration : Window
    {
        public registration()
        {
            InitializeComponent();
        }

        private void RegisterButton_Click(object sender, RoutedEventArgs e)
        {

            string login = LoginTextBox.Text;
            string password = PasswordTextBox.Password;

            // Подключение к базе данных
            using (var db = new ХранительПРОEntities4())
            {
                // Проверка наличия пользователя
                var existingUser = db.Авторизация.FirstOrDefault(user => user.Логин == login);
                if (existingUser != null)
                {
                    MessageBox.Show("Пользователь с таким логином уже существует.");
                    return;
                }

                // Шифрование пароля
                using (var md5 = MD5.Create()) // Создаем объект MD5
                {
                    byte[] hashBytes = md5.ComputeHash(Encoding.UTF8.GetBytes(password)); // Вычисляем хэш пароля
                    string hashedPassword = BitConverter.ToString(hashBytes).Replace("-", ""); // Преобразуем хэш в строку

                    // Создание нового пользователя
                    var newUser = new Авторизация();
                    newUser.Логин = login;
                    newUser.Пароль = password; 
                    newUser.Шифрование = hashedPassword;

                    db.Авторизация.Add(newUser);
                    db.SaveChanges();

                    MessageBox.Show("Регистрация прошла успешно!");
                    var newVisitor = new Посетитель
                    {
                        ID_Авторизации = newUser.ID_Авторизации // Связываем с пользователем
                    };
                    db.Посетитель.Add(newVisitor);
                    db.SaveChanges();
                    

                   
                    Close();
                }

            }

        }
    }
}
