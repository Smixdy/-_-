﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Security.Cryptography;

namespace Приложение_ХранительПРО
{
    /// <summary>
    /// Логика взаимодействия для registration.xaml
    /// </summary>
    public partial class registration : Window
    {
        public registration()
        {
            InitializeComponent();
        }

        private void RegisterButton_Click(object sender, RoutedEventArgs e)
        {
            string login = LoginTextBox.Text;
            string password = PasswordTextBox.Password;
            string confirmPassword = ConfirmPasswordTextBox.Password;
            string email = EmailTextBox.Text;

            // Проверка заполнения всех полей
            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password) ||
                string.IsNullOrEmpty(confirmPassword) || string.IsNullOrEmpty(email))
            {
                MessageBox.Show("Пожалуйста, заполните все поля.");
                return;
            }

            // Проверка совпадения паролей
            if (password != confirmPassword)
            {
                MessageBox.Show("Пароли не совпадают.");
                return;
            }

            // Подключение к базе данных
            using (var db = new ХранительПРОEntities())
            {
                // Проверка наличия пользователя с таким логином
                var existingUser = db.Авторизация.FirstOrDefault(user => user.Логин == login);
                if (existingUser != null)
                {
                    MessageBox.Show("Пользователь с таким логином уже существует.");
                    return;
                }

                // Шифрование пароля
                using (var md5 = MD5.Create())
                {
                    byte[] hashBytes = md5.ComputeHash(Encoding.UTF8.GetBytes(password));
                    string hashedPassword = BitConverter.ToString(hashBytes).Replace("-", "");

                    // Создание нового пользователя
                    var newUser = new Авторизация();
                    newUser.Логин = login;
                    newUser.Пароль = password;
                    newUser.Шифрование = hashedPassword;
                    newUser.Почта = email; // Добавление поля "Email"

                    db.Авторизация.Add(newUser);
                    db.SaveChanges();

                    MessageBox.Show("Регистрация прошла успешно!");

                    // Создание нового посетителя с привязкой к пользователю
                    var newVisitor = new Посетитель
                    {
                        ID_Авторизации = newUser.ID_Авторизации
                    };
                    db.Посетитель.Add(newVisitor);
                    db.SaveChanges();

                    Close();
                }
            }
        }
    }
}
