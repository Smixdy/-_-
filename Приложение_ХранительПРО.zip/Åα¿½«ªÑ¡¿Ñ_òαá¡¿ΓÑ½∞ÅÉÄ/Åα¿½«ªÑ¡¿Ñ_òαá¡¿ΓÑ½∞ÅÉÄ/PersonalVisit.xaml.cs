﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Приложение_ХранительПРО
{
    /// <summary>
    /// Логика взаимодействия для PersonalVisit.xaml
    /// </summary>
    public partial class PersonalVisit : Window
    {
        private byte[] loadedPhotoData = null;
        private byte[] loadedScanData = null;
        private int authorizationId;
        public PersonalVisit(int authorizationId)
        {
            InitializeComponent();
            this.authorizationId = authorizationId;
            Loaded += OnLoaded;
        }
        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            // Заполняем ComboBox при загрузке окна
            using (var context = new ХранительПРОEntities())
            {
                Podrazdel.ItemsSource = context.Подразделение.ToList();
                Podrazdel.DisplayMemberPath = "Название_подразделения";
                Podrazdel.SelectedValuePath = "ID_Подразделения";

                sotrudnik.ItemsSource = context.Сотрудник.ToList();
                sotrudnik.DisplayMemberPath = "Фамилия";
                sotrudnik.SelectedValuePath = "ID_Сотруника";


            }
        }

        private void clear_Click(object sender, RoutedEventArgs e)
        {

            // Очистка формы
            Фамилия.Text = "";
            Имя.Text = "";
            Отчество.Text = "";
            Телефон.Text = "";
            Email.Text = "";
            Организация.Text = "";
            Примечание.Text = "";
            Дата_рождения.SelectedDate = null;
            Серия.Text = "";
            Номер.Text = "";
            date1.SelectedDate = null;
            date2.SelectedDate = null;
           
            loadedPhotoData = null;
            loadedImage.Source = null;

        }
        private byte[] LoadImage()
        {
            // Функция для загрузки изображения из файла
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image files (*.png;*.jpeg;*.jpg;*.pdf)|*.png;*.jpeg;*.jpg;*.pdf";
            if (openFileDialog.ShowDialog() == true)
            {
                return File.ReadAllBytes(openFileDialog.FileName);
            }
            return null;
        }
        private void foto_Click(object sender, RoutedEventArgs e)
        {
            loadedPhotoData = LoadImage();
            if (loadedPhotoData != null)
            {
                var bitmapImage = new BitmapImage();
                bitmapImage.BeginInit();
                bitmapImage.StreamSource = new MemoryStream(loadedPhotoData);
                bitmapImage.EndInit();

                // Устанавливаем BitmapImage как источник для элемента Image
                loadedImage.Source = bitmapImage;
            }
        }

        private void fail_Click(object sender, RoutedEventArgs e)
        {
            loadedScanData = LoadImage();
        }

        private void press_Click(object sender, RoutedEventArgs e)
        {
            // Обработчик нажатия кнопки "Оформить заявку"
            if (!ValidateForm()) return;

            using (var context = new ХранительПРОEntities())
            {
                // Создаем новую запись посетителя для каждой заявки
                var visitor = new Посетитель
                {
                    ID_Авторизации = authorizationId,
                    Фамилия = Фамилия.Text,
                    Имя = Имя.Text,
                    Отчество = Отчество.Text,
                    Телефон = Телефон.Text,
                    Почта = Email.Text,
                    Организация = Организация.Text,
                    Примечание = Примечание.Text,
                    Дата_рождения = Дата_рождения.SelectedDate.Value,
                    Серия_паспорта = int.Parse(Серия.Text),
                    Номер_паспорта = int.Parse(Номер.Text),
                    Фотография_посетителя = loadedPhotoData,
                    Скан_паспорта = loadedScanData
                };
                context.Посетитель.Add(visitor);
                context.SaveChanges();

                // Создаем и сохраняем новую заявку
                var заявка = new Заявка
                {
                    ID_Постетителя = visitor.ID_Посетителя, // Используем ID новой записи
                    Дата_подачи = DateTime.Now.Date,
                    Желаемый_срок_начала_пропуска = date1.SelectedDate.Value,
                    Желаемый_срок_окончания_пропуска = date2.SelectedDate.Value,
                    Групповая_запись = false,
                    Статус_заявки = 1,
                    Ответственное_подразделение = (int)Podrazdel.SelectedValue,
                    ID_Принимающего = (int)sotrudnik.SelectedValue
                };
                context.Заявка.Add(заявка);
                context.SaveChanges();

                MessageBox.Show("Заявка успешно оформлена!");
            }

        }
        private bool ValidateForm()
        {
            // Проверка заполнения полей
            if (string.IsNullOrWhiteSpace(Фамилия.Text) ||
                string.IsNullOrWhiteSpace(Имя.Text) || string.IsNullOrWhiteSpace(Отчество.Text) || string.IsNullOrWhiteSpace(Телефон.Text) ||
                string.IsNullOrWhiteSpace(Email.Text) || string.IsNullOrWhiteSpace(Организация.Text) || string.IsNullOrWhiteSpace(Дата_рождения.Text) ||
                string.IsNullOrWhiteSpace(Серия.Text) || string.IsNullOrWhiteSpace(Номер.Text)

                )
            {
                MessageBox.Show("Пожалуйста, заполните все обязательные поля.");
                return false;
            }

           
            if (Серия.Text.Length > 4)
            {
                MessageBox.Show("Серия паспорта не должна превышать 4 символа.");
                return false;
            }
            if (Номер.Text.Length > 6)
            {
                MessageBox.Show("Номер паспорта не должна превышать 4 символа.");
                return false;
            }
            if (Фамилия.Text.Length > 50)
            {
                MessageBox.Show("Максимум допустимых символов - 50");
                return false;
            }
            if (Имя.Text.Length > 50)
            {
                MessageBox.Show("Максимум допустимых символов - 50");
                return false;
            }
            if (Отчество.Text.Length > 50)
            {
                MessageBox.Show("Максимум допустимых символов - 50");
                return false;
            }
            if (Email.Text.Length > 50)
            {
                MessageBox.Show("Максимум допустимых символов - 50");
                return false;
            }
            if (Организация.Text.Length > 50)
            {
                MessageBox.Show("Максимум допустимых символов - 50");
                return false;
            }
            if (Примечание.Text.Length > 50)
            {
                MessageBox.Show("Максимум допустимых символов - 50");
                return false;
            }
            if (Телефон.Text.Length > 20)
            {
                MessageBox.Show("Максимум допустимых символов - 20");
                return false;
            }
            if (Podrazdel.SelectedItem == null)
            {
                MessageBox.Show("Пожалуйста, выберите подразделение.");
                return false;
            }

            if (sotrudnik.SelectedItem == null)
            {
                MessageBox.Show("Пожалуйста, выберите сотрудника.");
                return false;
            }
            if (loadedPhotoData == null)
            {
                MessageBox.Show("Пожалуйста, загрузите фотографию посетителя.");
                return false;
            }

            if (loadedScanData == null)
            {
                MessageBox.Show("Пожалуйста, загрузите скан паспорта.");
                return false;
            }

            return true;
        }

    }
}
