﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Терминал_сотрудника_общего_отдела
{
    /// <summary>
    /// Логика взаимодействия для ApplicationDetailsWindow.xaml
    /// </summary>
    public partial class ApplicationDetailsWindow : Window
    {
        public int ApplicationId { get; set; }
        public ApplicationDetailsWindow()
        {
            InitializeComponent();
        }
        protected override void OnActivated(EventArgs e)
        {
            base.OnActivated(e);
            LoadApplicationData();
            LoadStatuses();
            CheckBlacklist();
        }
        private void CheckBlacklist()
        {
            using (ХранительПРОEntities context = new ХранительПРОEntities())
            {
                var application = context.Заявка.FirstOrDefault(a => a.ID_Заявки == ApplicationId);
                if (application != null)
                {
                    var visitorId = application.ID_Постетителя;
                    var blacklisted = context.Черный_список.Any(b => b.ID_Посетителя == visitorId);

                    if (blacklisted)
                    {
                        MessageBox.Show("Посетитель находится в черном списке. Заявка отклонена.");
                        // Изменить статус заявки на "Отклонена"
                        application.Статус_заявки = (int)context.Статус.FirstOrDefault(s => s.Название_статус == "Отклонена")?.ID_Статуса;
                        context.SaveChanges();

                        // Заблокировать редактирование
                        StatusComboBox.IsEnabled = false;
                        CommentTextBox.IsEnabled = false;
                        SaveButton.IsEnabled = false;
                    }
                }
            }
        }

            private void LoadApplicationData()
        {
            using (ХранительПРОEntities context = new ХранительПРОEntities())
            {
                var application = context.Заявка.FirstOrDefault(a => a.ID_Заявки == ApplicationId);
                if (application != null)
                {
                    ApplicationIdTextBlock.Text = application.ID_Заявки.ToString();
                    ApplicationDateTextBlock.Text = application.Дата_подачи.ToString("dd.MM.yyyy");
                 

                    // Установите выбранный статус в ComboBox
                    StatusComboBox.SelectedItem = StatusComboBox.Items.Cast<ComboBoxItem>()
                        .FirstOrDefault(item => item.Content.ToString() == application.Статус.Название_статус);

                    // Установите комментарий в TextBox
                    CommentTextBox.Text = application.Коментарий;
                }
            }
        }

        private void LoadStatuses()
        {
           
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            using (ХранительПРОEntities context = new ХранительПРОEntities())
            {
                var application = context.Заявка.FirstOrDefault(a => a.ID_Заявки == ApplicationId);
                if (application != null)
                {
                    // Обновление статуса
                    var selectedStatusItem = StatusComboBox.SelectedItem as ComboBoxItem;
                    if (selectedStatusItem != null)
                    {
                        var newStatus = context.Статус.FirstOrDefault(s => s.Название_статус == selectedStatusItem.Content.ToString());
                        if (newStatus != null)
                        {
                            application.Статус_заявки = newStatus.ID_Статуса;
                        }
                    }

                    // Обновление комментария
                    application.Коментарий = CommentTextBox.Text;

                    context.SaveChanges();
                    MessageBox.Show("Изменения сохранены.");
                   this.Hide(); // Закройте окно после сохранения
                }
            }
        }
    }
}
