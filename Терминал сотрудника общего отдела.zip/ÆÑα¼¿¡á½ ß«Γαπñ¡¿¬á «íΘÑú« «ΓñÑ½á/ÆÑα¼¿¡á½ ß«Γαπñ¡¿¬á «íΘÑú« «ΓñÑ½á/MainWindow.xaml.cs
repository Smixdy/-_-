﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Терминал_сотрудника_общего_отдела
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            // Получить введенный код сотрудника
            int employeeCode;
            if (!int.TryParse(employeeCodeTextBox.Text, out employeeCode))
            {
                errorTextBlock.Text = "Неверный формат кода сотрудника";
                return;
            }

            // Проверить код сотрудника в базе данных
            using (var context = new ХранительПРОEntities())
            {
                var employee = context.Сотрудник.FirstOrDefault(s => s.ID_Сотруника == employeeCode);
                if (employee != null)
                {
                    // Авторизация успешна, открыть форму просмотра списка заявок
                    var applicationWindow = new ApplicationWindow();
                    applicationWindow.Show();
                    this.Close();
                }
                else
                {
                    errorTextBlock.Text = "Сотрудник не найден";
                }
            }
        }
    }
}
