﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Терминал_сотрудника_общего_отдела
{
    /// <summary>
    /// Логика взаимодействия для ReportsWindow.xaml
    /// </summary>
    public partial class ReportsWindow : Window
    {
        public ReportsWindow()
        {
            InitializeComponent();
        }
        private void GenerateReportButton_Click(object sender, RoutedEventArgs e)
        {
            int reportType = ReportTypeComboBox.SelectedIndex + 1;
            bool groupByDepartment = GroupByDepartmentCheckBox.IsChecked == true;
            DateTime? dateFrom = DateFromPicker.SelectedDate;
            DateTime? dateTo = DateToPicker.SelectedDate;

            DataTable reportData = GetReportData(reportType, groupByDepartment, dateFrom, dateTo);
            ReportDataGrid.ItemsSource = reportData.DefaultView;
        }

        private DataTable GetReportData(int reportType, bool groupByDepartment, DateTime? dateFrom, DateTime? dateTo)
        {
            using (var context = new ХранительПРОEntities())
            {
                IQueryable<Заявка> query = context.Заявка;

                if (dateFrom.HasValue)
                {
                    query = query.Where(z => z.Время_прихода >= dateFrom.Value);
                }
                if (dateTo.HasValue)
                {
                    query = query.Where(z => z.Время_прихода <= dateTo.Value);
                }

                if (reportType == 1) // Количество посещений
                {
                    var data = groupByDepartment
                        ? query.GroupBy(z => z.Подразделение.Название_подразделения)
                            .Select(g => new
                            {
                                Подразделение = g.Key,
                                Дата_посещения = g.Max(z => z.Время_прихода), // Выбираем любую дату из группы
                                Количество_посещений = g.Count()
                            })
                        : query.GroupBy(z => z.Время_прихода)
                            .Select(g => new
                            {
                                Подразделение = "Все подразделения",
                                Дата_посещения = g.Key,
                                Количество_посещений = g.Count()
                            });

                    DataTable dataTable = new DataTable();
                    dataTable.Columns.Add("Подразделение", typeof(string));
                    dataTable.Columns.Add("Дата_посещения", typeof(DateTime));
                    dataTable.Columns.Add("Количество_посещений", typeof(int));

                    foreach (var item in data)
                    {
                        dataTable.Rows.Add(item.Подразделение, item.Дата_посещения, item.Количество_посещений);
                    }

                    return dataTable;
                }
                else if (reportType == 2) // Список на территории
                {
                    var data = query
                        .Where(z => z.ID_Состояние == 1) // Состояние "Внутри"
                        .Select(z => new
                        {
                            z.Посетитель.Фамилия,
                            z.Посетитель.Имя,
                            z.Посетитель.Отчество,
                            z.Посетитель.Организация,
                            Подразделение = z.Подразделение.Название_подразделения
                        });

                    DataTable dataTable = new DataTable();
                    dataTable.Columns.Add("Фамилия", typeof(string));
                    dataTable.Columns.Add("Имя", typeof(string));
                    dataTable.Columns.Add("Отчество", typeof(string));
                    dataTable.Columns.Add("Организация", typeof(string));
                    dataTable.Columns.Add("Подразделение", typeof(string));

                    foreach (var item in data)
                    {
                        dataTable.Rows.Add(item.Фамилия, item.Имя, item.Отчество, item.Организация, item.Подразделение);
                    }

                    return dataTable;
                }
                else
                {
                    throw new ArgumentException("Неверный тип отчета.");
                }
            }
        }
    }
}
