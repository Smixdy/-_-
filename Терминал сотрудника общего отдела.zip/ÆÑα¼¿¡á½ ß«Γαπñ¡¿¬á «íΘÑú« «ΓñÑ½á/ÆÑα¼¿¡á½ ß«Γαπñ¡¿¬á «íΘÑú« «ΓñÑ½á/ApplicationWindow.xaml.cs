﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Терминал_сотрудника_общего_отдела
{
    /// <summary>
    /// Логика взаимодействия для ApplicationWindow.xaml
    /// </summary>
    public partial class ApplicationWindow : Window
    {
        public ApplicationWindow()
        {
            InitializeComponent();
            LoadApplicationsData();
        }
        public void LoadApplicationsData()
        {
            using (ХранительПРОEntities context = new ХранительПРОEntities())
            {
                var applications = context.Заявка.Select(a => new
                {
                    a.ID_Заявки,
                    a.Дата_подачи,
                    a.Желаемый_срок_начала_пропуска,
                    a.Желаемый_срок_окончания_пропуска,
                    Подразделение = a.Подразделение.Название_подразделения,
                    Статус = a.Статус.Название_статус,
                    ФИО_Посетителя = a.Посетитель.Фамилия + " " + a.Посетитель.Имя + " " + a.Посетитель.Отчество,
                    Организация = a.Посетитель.Организация,
                    a.Коментарий
                }).ToList();

                // Очистка существующих столбцов
                ApplicationDataGrid.Columns.Clear();

                // Создание столбцов
                ApplicationDataGrid.Columns.Add(new DataGridTextColumn() { Header = "ID заявки", Binding = new Binding("ID_Заявки") });
                ApplicationDataGrid.Columns.Add(new DataGridTextColumn() { Header = "Дата подачи", Binding = new Binding("Дата_подачи") });
                

                // Заполнение DataGrid
                ApplicationDataGrid.ItemsSource = applications;
            }
        }
        private void FilterApplications()
        {
            bool showGroupApplications = GroupApplicationCheckBox.IsChecked == true;

            using (ХранительПРОEntities context = new ХранительПРОEntities())
            {
                var filteredApplications = context.Заявка.AsQueryable();

                if (showGroupApplications)
                {
                    filteredApplications = filteredApplications.Where(a => a.Групповая_запись);
                }

                var applicationsToDisplay = filteredApplications.Select(a => new
                {
                    a.ID_Заявки,
                    a.Дата_подачи,
                    a.Желаемый_срок_начала_пропуска,
                    a.Желаемый_срок_окончания_пропуска,
                    Подразделение = a.Подразделение.Название_подразделения,
                    Статус = a.Статус.Название_статус,
                    ФИО_Посетителя = a.Посетитель.Фамилия + " " + a.Посетитель.Имя + " " + a.Посетитель.Отчество,
                    Организация = a.Посетитель.Организация,
                    a.Коментарий
                }).ToList();

                ApplicationDataGrid.ItemsSource = applicationsToDisplay;
            }
        }
        private void GroupApplicationCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            FilterApplications();
        }

        private void GroupApplicationCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            FilterApplications();
        }

        private void DepartmentFilterComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string selectedDepartment = (DepartmentFilterComboBox.SelectedItem as ComboBoxItem)?.Content.ToString();

            using (ХранительПРОEntities context = new ХранительПРОEntities())
            {
                var filteredApplications = context.Заявка.AsQueryable(); 

                if (selectedDepartment != "Все")
                {
                    filteredApplications = filteredApplications.Where(a => a.Подразделение.Название_подразделения == selectedDepartment);
                }

                var applicationsToDisplay = filteredApplications.Select(a => new 
                {
                    a.ID_Заявки,
                    a.Дата_подачи,
                    a.Желаемый_срок_начала_пропуска,
                    a.Желаемый_срок_окончания_пропуска,
                    Подразделение = a.Подразделение.Название_подразделения,
                    Статус = a.Статус.Название_статус,
                    ФИО_Посетителя = a.Посетитель.Фамилия + " " + a.Посетитель.Имя + " " + a.Посетитель.Отчество,
                    Организация = a.Посетитель.Организация,
                    a.Коментарий
                }).ToList();

                ApplicationDataGrid.ItemsSource = applicationsToDisplay; 
            }
        }

        private void StatusFilterComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string selectedStatus = (StatusFilterComboBox.SelectedItem as ComboBoxItem)?.Content.ToString();

            using (ХранительПРОEntities context = new ХранительПРОEntities())
            {
                var filteredApplications = context.Заявка.AsQueryable();

                if (selectedStatus != "Все")
                {
                    filteredApplications = filteredApplications.Where(a => a.Статус.Название_статус == selectedStatus);
                }

                var applicationsToDisplay = filteredApplications.Select(a => new
                {
                    a.ID_Заявки,
                    a.Дата_подачи,
                    a.Желаемый_срок_начала_пропуска,
                    a.Желаемый_срок_окончания_пропуска,
                    Подразделение = a.Подразделение.Название_подразделения,
                    Статус = a.Статус.Название_статус,
                    ФИО_Посетителя = a.Посетитель.Фамилия + " " + a.Посетитель.Имя + " " + a.Посетитель.Отчество,
                    Организация = a.Посетитель.Организация,
                    a.Коментарий
                }).ToList();

                ApplicationDataGrid.ItemsSource = applicationsToDisplay;
            }
        }

        private void ViewDetailsButton_Click(object sender, RoutedEventArgs e)
        {
            // 1. Получение выбранной заявки
            var selectedApplication = ApplicationDataGrid.SelectedItem as dynamic; 
            if (selectedApplication == null)
            {
                MessageBox.Show("Выберите заявку для просмотра деталей.");
                return;
            }

            // 2. Создание экземпляра формы ApplicationDetailsWindow
            var detailsWindow = new ApplicationDetailsWindow();

            // 3. (Опционально) Передача данных
            detailsWindow.ApplicationId = selectedApplication.ID_Заявки; 

           

            // 5. Показ формы ApplicationDetailsWindow
            detailsWindow.Show();
        }

        private void OpenReportsWindow_Click(object sender, RoutedEventArgs e)
        {
            var reportsWindow = new ReportsWindow();
            reportsWindow.Show();
        }
    }
}
