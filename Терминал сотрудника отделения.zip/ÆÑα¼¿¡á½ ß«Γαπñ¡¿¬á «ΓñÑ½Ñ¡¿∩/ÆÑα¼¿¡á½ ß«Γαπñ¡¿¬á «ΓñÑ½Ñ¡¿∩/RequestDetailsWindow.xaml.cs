﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.Entity;
namespace Терминал_сотрудника_отделения
{
    /// <summary>
    /// Логика взаимодействия для RequestDetailsWindow.xaml
    /// </summary>
    public partial class RequestDetailsWindow : Window
    {
        private ХранительПРОEntities context;
        private int requestId;
        public RequestDetailsWindow(int requestId)
        {
            InitializeComponent();
            this.requestId = requestId;
            context = new ХранительПРОEntities();
        }

        private void ConfirmButton_Click(object sender, RoutedEventArgs e)
        {
           
            var request = context.Заявка.Find(requestId);
            if (request == null || request.ID_Постетителя == null)
            {
                MessageBox.Show("Не удалось найти посетителя для этой заявки.");
                return;
            }
            int visitorId = request.ID_Постетителя.Value;

          
            var blacklistEntry = new Черный_список
            {
                ID_Посетителя = visitorId,
                Дата_добавления = DateTime.Now,
                Причина = reasonTextBox.Text
            };

         
            context.Черный_список.Add(blacklistEntry);
            context.SaveChanges();

           
            MessageBox.Show("Посетитель успешно добавлен в черный список.");
            this.Close();
        }
    }
}
