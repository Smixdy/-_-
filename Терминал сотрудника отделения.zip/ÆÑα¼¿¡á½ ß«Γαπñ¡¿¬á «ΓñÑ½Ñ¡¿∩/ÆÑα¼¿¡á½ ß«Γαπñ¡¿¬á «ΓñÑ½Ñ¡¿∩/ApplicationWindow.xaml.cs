﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Терминал_сотрудника_отделения
{
    /// <summary>
    /// Логика взаимодействия для ApplicationWindow.xaml
    /// </summary>
    public partial class ApplicationWindow : Window
    {
        private ХранительПРОEntities context;
        public int visitorId;

        public ApplicationWindow()
        {
            InitializeComponent();
            context = new ХранительПРОEntities(); 
            LoadRequests();
        }

        private void LoadRequests()
        {
            requestsDataGrid.ItemsSource = context.ViewListRequests.ToList();
        }

        private void FilterButton_Click(object sender, RoutedEventArgs e)
        {
            DateTime? startDate = startDatePicker.SelectedDate;
            DateTime? endDate = endDatePicker.SelectedDate;

            var filteredRequests = context.ViewListRequests.AsQueryable();

            if (startDate.HasValue)
            {
                filteredRequests = filteredRequests.Where(r => r.Дата_подачи >= startDate.Value);
            }

            if (endDate.HasValue)
            {
                filteredRequests = filteredRequests.Where(r => r.Дата_подачи <= endDate.Value);
            }

            requestsDataGrid.ItemsSource = filteredRequests.ToList();
        }

        private void dataGridApplications_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
           
        }

       

        private void ViewDetailsButton_Click(object sender, RoutedEventArgs e)
        {


            // Получить выбранную заявку
            var selectedRequest = requestsDataGrid.SelectedItem as ViewListRequests; 

            if (selectedRequest == null)
            {
                MessageBox.Show("Пожалуйста, выберите заявку.");
                return;
            }

           
            var detailsWindow = new RequestDetailsWindow(selectedRequest.ID_Заявки); 
            detailsWindow.Show();

        }
    }
}
