﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace Терминал_сотрудника_охраны
{
    public partial class View : Window
    {
        public View()
        {
            InitializeComponent();
            LoadDepartments();
            LoadApplications();
        }

        private void LoadDepartments()
        {
            using (var context = new ХранительПРОEntities())
            {
                var departments = context.Подразделение.Select(d => d.Название_подразделения).ToList();
                departments.Insert(0, "Все");
                DepartmentFilterComboBox.ItemsSource = departments;
            }
        }

        private void LoadApplications()
        {
            FilterApplications();
        }

        private void FilterApplications()
        {
            string searchText = SearchBox.Text.ToLower();
            DateTime? selectedDate = DateFilterPicker.SelectedDate;
            string selectedType = TypeFilterComboBox.SelectedItem?.ToString() ?? "Все";
            string selectedDepartment = DepartmentFilterComboBox.SelectedItem?.ToString() ?? "Все";

            using (var context = new ХранительПРОEntities())
            {
                var query = context.Заявка
                    .Where(a => a.Статус.Название_статус == "Одобрено");

                // Фильтрация по тексту поиска
                if (!string.IsNullOrEmpty(searchText))
                {
                    query = query.Where(a =>
                        a.Посетитель.Фамилия.ToLower().Contains(searchText) ||
                        a.Посетитель.Имя.ToLower().Contains(searchText) ||
                        a.Посетитель.Отчество.ToLower().Contains(searchText) ||
                        a.Посетитель.Номер_паспорта.ToString().Contains(searchText) ||
                        a.Посетитель_Заявка.Any(pz =>
                            pz.Посетитель.Фамилия.ToLower().Contains(searchText) ||
                            pz.Посетитель.Имя.ToLower().Contains(searchText) ||
                            pz.Посетитель.Отчество.ToLower().Contains(searchText) ||
                            pz.Посетитель.Номер_паспорта.ToString().Contains(searchText)
                        )
                    );
                }

                // Фильтрация по дате
                if (selectedDate.HasValue)
                {
                    query = query.Where(a => a.Дата_подачи == selectedDate.Value);
                }

                // Фильтрация по типу
                if (selectedType != "Все")
                {
                    bool isGroup = selectedType == "Групповая";
                    query = query.Where(a => a.Групповая_запись == isGroup);
                }

                // Фильтрация по подразделению
                if (selectedDepartment != "Все")
                {
                    query = query.Where(a => a.Подразделение.Название_подразделения == selectedDepartment);
                }

                var applications = query.Select(a => new
                {
                    a.ID_Заявки,
                    a.Дата_подачи,
                    a.Желаемый_срок_начала_пропуска,
                    a.Желаемый_срок_окончания_пропуска,
                    Подразделение = a.Подразделение.Название_подразделения,
                    ФИО_Посетителя = a.Групповая_запись ?
                        (from pz in a.Посетитель_Заявка select pz.Посетитель.Фамилия + " " + pz.Посетитель.Имя + " " + pz.Посетитель.Отчество).FirstOrDefault() :
                        a.Посетитель.Фамилия + " " + a.Посетитель.Имя + " " + a.Посетитель.Отчество,
                    Номер_паспорта = a.Групповая_запись ?
                        (from pz in a.Посетитель_Заявка select pz.Посетитель.Номер_паспорта).FirstOrDefault() :
                        a.Посетитель.Номер_паспорта,
                    a.Время_прихода,
                    a.Время_ухода,
                    Состояние = a.Состояние.Название_состояния,
                    Тип_заявки = a.Групповая_запись ? "Групповая" : "Индивидуальная"
                })
                .ToList();

                // Сортировка по типу и дате
                if (selectedType != "Все")
                {
                    applications = selectedType == "Групповая" ?
                        applications.OrderByDescending(a => a.Тип_заявки).ToList() :
                        applications.OrderBy(a => a.Тип_заявки).ToList();
                }
                else if (selectedDate.HasValue)
                {
                    applications = applications.OrderBy(a => a.Дата_подачи).ToList();
                }

                ApprovedApplicationDataGrid.ItemsSource = applications;
            }
        }

      

        private void ManageApplicationButton_Click(object sender, RoutedEventArgs e)
        {
            var selectedApplication = ApprovedApplicationDataGrid.SelectedItem as dynamic;
            if (selectedApplication == null)
            {
                MessageBox.Show("Выберите заявку для просмотра деталей.");
                return;
            }

            var detailsWindow = new DetailsWindow { ApplicationId = selectedApplication.ID_Заявки };
            detailsWindow.ShowDialog();

         
            LoadApplications();
        }

        private void SearchBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            FilterApplications();
        }

        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            FilterApplications();
        }
        private void DateFilterPicker_SelectedDateChanged(object sender, RoutedEventArgs e)
        {
            FilterApplications();
        }

        private void TypeFilterComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            FilterApplications();
        }

        private void DepartmentFilterComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            FilterApplications();
        }
    }
}