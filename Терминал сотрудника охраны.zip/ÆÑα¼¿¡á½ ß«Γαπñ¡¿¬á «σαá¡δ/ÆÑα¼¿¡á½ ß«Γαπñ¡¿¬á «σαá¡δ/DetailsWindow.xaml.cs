﻿using System;
using System.Collections.Generic;
using System.Linq;

using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Терминал_сотрудника_охраны
{
    /// <summary>
    /// Логика взаимодействия для DetailsWindow.xaml
    /// </summary>
    public partial class DetailsWindow : Window
    {
        public int ApplicationId { get; set; }
        public DetailsWindow()
        {
            InitializeComponent();
        }

        protected override void OnActivated(EventArgs e)
        {
            base.OnActivated(e);
            LoadApplicationData();
        }

        private void LoadApplicationData()
        {
            using (var context = new ХранительПРОEntities())
            {
                var application = context.Заявка.Find(ApplicationId);
                if (application != null)
                {
                    ApplicationIdTextBlock.Text = application.ID_Заявки.ToString();
                    ApplicationDateTextBlock.Text = application.Дата_подачи.ToString("dd.MM.yyyy");
                    VisitorNameTextBlock.Text = application.Посетитель.Фамилия + " " + application.Посетитель.Имя + " " + application.Посетитель.Отчество;
                    DepartmentTextBlock.Text = application.Подразделение.Название_подразделения;
                    ApplicationTypeTextBlock.Text = application.Групповая_запись ? "Групповая" : "Индивидуальная";
                    ArrivalTimeTextBlock.Text = application.Время_прихода?.ToString("dd.MM.yyyy HH:mm") ?? "Не указано";

                    if (application.Время_ухода.HasValue)
                    {
                        DepartureDatePicker.SelectedDate = application.Время_ухода.Value.Date;
                      
                    }
                }
            }
        }

        private void AllowAccessButton_Click(object sender, RoutedEventArgs e)
        {
            using (var context = new ХранительПРОEntities())
            {
                var application = context.Заявка.Find(ApplicationId);
                if (application != null && application.Время_прихода == null)
                {
                    application.Время_прихода = DateTime.Now;
                    context.SaveChanges();
                    ArrivalTimeTextBlock.Text = application.Время_прихода?.ToString("dd.MM.yyyy HH:mm");

                  
                }
            }
        }

        private void SaveDepartureTimeButton_Click(object sender, RoutedEventArgs e)
        {
            if (DepartureDatePicker.SelectedDate == null )
            {
                MessageBox.Show("Выберите дату и время ухода.");
                return;
            }

            DateTime departureTime = DepartureDatePicker.SelectedDate.Value.Date;

            using (var context = new ХранительПРОEntities())
            {
                var application = context.Заявка.Find(ApplicationId);
                if (application != null)
                {
                    application.Время_ухода = departureTime;
                    context.SaveChanges();
                    MessageBox.Show("Время ухода сохранено.");
                }
            }
        }
    }
}
